<?php 
include '../dbconn.php';
include '../session.php';?>

<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="styles.css">
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">USER <b>DASHBOARD</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		</h2>
		<i class="fa fa-user" aria-hidden="true"></i>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<img src="userpic.png">
				<h4>WELCOME!</h4>
				<?php
$currentuser= $_SESSION['email'];
$sql="SELECT * FROM `userreg` WHERE email='$currentuser'";
$gotresult=mysqli_query($conn,$sql);
if($gotresult)
{
    if(mysqli_num_rows($gotresult) > 0)
    {
        while($row=mysqli_fetch_array($gotresult))
        {
            //print_r($row['email']);
            ?>
            <p>Welcome <?php echo $row['email'];?></p>
            <?php
        }
    }
}
?>
			</div>
			<ul>
				<li>
					<a href="change.p.php">
						<i class="fa fa-desktop" aria-hidden="true"></i>
						<span>Change Password</span>
					</a>
				</li>
				<li>
					<a href="democaste.php">
						<i class="fa fa-plus icons"></i>
						<span>Apply Application</span>
					</a>
				</li>
				<li>
					<a href="payyy.php">
						<i class="fa fa-plus icons" aria-hidden="true"></i>
						<span>Pay tax</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="fa fa-info-circle" aria-hidden="true"></i>
						<span>Request Service</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="fa fa-cog" aria-hidden="true"></i>
						<span>Setting</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-power-off" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
		<section class="section-1">
           
			<h1>WELCOME</h1>
			<p>Department of Land Revenue</p>
			<?php 

$id=$_SESSION['email'];
// require 'console.php';
// include("connection.php");
// $targetDir = "upload_image/birthreg/";
// $finalpath = "upload_image/birthreg/";
if(isset($_POST['submit'])) {
   
    $thandaperno = $_POST['thandaperno'];
    $cent = $_POST['cent'];
    $amount = $_POST['amount'];
   
   

    $user_check_query1 = "SELECT Rid FROM u_login WHERE email='$id'";
    $checkqueryresult1 = mysqli_query($conn, $user_check_query1);
    $res1=mysqli_fetch_array($checkqueryresult1);
    $is= $res1['Rid'];
    $user_check_query2 = "SELECT email FROM userreg WHERE email='$is'";
    $checkqueryresult2 = mysqli_query($conn, $user_check_query2);
    $res2=mysqli_fetch_array($checkqueryresult2);
    // $reg= $res2['email'];
    $wid=$_SESSION['email'];
    $user_reg_query= "INSERT INTO `tbl_tax`(`email`,
     `thandaperno`,`cent`,`amount`) 
     VALUES ('$wid','$thandaperno','$cent',' $amount')";
    $checkqueryresult3 = mysqli_query($conn, $user_reg_query);
    $last_id = mysqli_insert_id($conn);
    if($user_reg_query){
        // (move_uploaded_file($_FILES['image']['tmp_name'], $target));
        // move_uploaded_file($tmp_img_name,$folder.$img_name);
        $user_check_query3=" INSERT INTO `tbl_payment`( `email`,`reg_id`,`thandaperno`,`cent`, `amount`,  `status`) VALUES 
        ('$wid','2','$thandaperno','$cent','$amount','Paid')";
        $checkqueryresult4 = mysqli_query($conn, $user_check_query3);
        // if($checkqueryresult4){
        //             require "Mail/phpmailer/PHPMailerAutoload.php";
        //             $mail = new PHPMailer;

        //             $mail->isSMTP();
        //             $mail->Host='smtp.gmail.com';
        //             $mail->Port=587;
        //             $mail->SMTPAuth=true;
        //             $mail->SMTPSecure='tls';

        //             // h-hotel account
        //             $mail->Username='aiswaryamohanan2023a@mca.ajce.in';
        //             $mail->Password='Aiswarya@1';

        //             // send by h-hotel email
        //             $mail->setFrom('aiswaryamohanan2023a@mca.ajce.in', 'Password Reset');
        //             // get email from input
        //             $mail->addAddress($id);
        //             //$mail->addReplyTo('lamkaizhe16@gmail.com');

        //             // HTML body
        //             $mail->isHTML(true);
                    // $mail->Subject="Application sucessfully registered";
                    // $mail->Body="<b>Dear User</b>
                    // <h3>We received a request for caste certificate with file number:'$filenumber'.</h3>
                    // <p>it is successfull !!!  </p>
                    // <br>use the provided file number to check the status of your file and you will be notified once application
                    // is approved<br>
                    // <p>With regrads,</p>
                    // <b>Kanjirappally Taluk Office</b>";
                    
                    echo"<script Type='text/javascript'>alert('Proceed to payment')</script>";
                    echo"<script>window.location.href='payment.php';</script>";
                
        }
                // else{
                    
                //     echo"<script Type='text/javascript'>alert('mail sending failed')</script>";
                // }
        // echo"<script>window.location.href='index.html';</script>";

    
                }
        else{
            echo"<script Type='text/javascript'>alert('Registration unsuccessfull')</script>";
        }
    
// }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="style.css">
     
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
 
    <!--<title>Responsive Regisration Form </title>--> 
</head>

<style>
    
/* ===== Google Font Import - Poppins ===== */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}
 /* body{
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center; 
    background: #99ffbb; 
}  */
.container{
    position: relative;
    width:1350px;
    height: auto;
    border-radius: 6px;
    padding: 30px;
    margin: 0 15px;
    background-color: #fff;
    box-shadow: 0 5px 10px rgba(0,0,0,0.1);
}
.container header{
    position: relative;
    font-size: 50px;
    font-weight: 800;
    color: #333;
}
.container header::before{
    content: "";
    position: absolute;
    left: 0;
    bottom: -2px;
    height: 3px;
    width: 27px;
    border-radius: 8px;
    background-color: #4070f4;
}
.container form{
    position: relative;
    margin-top: 16px;
    min-height: 1300px;
    background-color: #fff;
    overflow: hidden;
}
.container form .form{
    position: absolute;
    background-color: #fff;
    transition: 0.3s ease;
}
.container form .form.second{
    opacity: 0;
    pointer-events: none;
    transform: translateX(100%);
}
form.secActive .form.second{
    opacity: 1;
    pointer-events: auto;
    transform: translateX(0);
}
form.secActive .form.first{
    opacity: 0;
    pointer-events: none;
    transform: translateX(-100%);
}
.container form .title{
    display: block;
    margin-bottom: 8px;
    font-size: 16px;
    font-weight: 500;
    margin: 6px 0;
    color: #333;
}
.container form .fields{
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
}
form .fields .input-field{
    display: flex;
    width: calc(100% / 3 - 15px);
    flex-direction: column;
    margin: 4px 0;
}
.input-field label{
    font-size: 14px;
    font-weight:bold;
    color: #2e2e2e;
}
.input-field input, select{
    outline: none;
    font-size: 14px;
    font-weight: 400;
    color: #333;
    border-radius: 5px;
    border: 1px solid #aaa;
    padding: 0 15px;
    height: 42px;
    margin: 8px 0;
}
.input-field input :focus,
.input-field select:focus{
    box-shadow: 0 3px 6px rgba(0,0,0,0.13);
}
.input-field select,
.input-field input[type="date"]{
    color: #707070;
}
.input-field input[type="date"]:valid{
    color: #333;
}
.container form button, .backBtn{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 45px;
    width: 100%;
    border: none;
    outline: none;
    color: #fff;
    border-radius: 5px;
    margin: 25px 0;
    background-color: #4070f4;
    transition: all 0.3s linear;
    cursor: pointer;
}
.container form .btnText{
    font-size: 14px;
    font-weight: 400;
}
form button:hover{
    background-color: #265df2;
}
form button i,
form .backBtn i{
    margin: 0 6px;
}
form .backBtn i{
    transform: rotate(180deg);
}
form .buttons{
    display: flex;
    align-items: center;
}
form .buttons button , .backBtn{
    margin-right: 14px;
}


 
</style>

<body>
    
<div class="container">
        <!-- <header>Registration</header> -->
 
        <form  autocomplete="off" method="POST" enctype="multipart/form-data">
            <div class="form first">
                <div class="details personal">
                                    <div class="input-field">
                                        <label style="font-size:large;">Paytax</label>
                                    

</div>
                                
 
                          <div class="fields">
                                <div class="input-field">
                                        <label>Thandaperno</label>
                                        <input type="text" onkeyup='fnameValidation(this)' name="thandaperno" placeholder="Enter your Land Number" required>
                                        <span id="first" class="new" style="color:red;"></span> 
                                 </div>
 
                                 <div class="input-field">
                                    <label>Cent</label>
                                    <input type="text" placeholder="Enter Cent" name="cent" onkeyup='mnameValidation(this)' >
                                    <span id="middle" class="new" style="color:red;"></span> 
                                </div>
 
                                 <div class="input-field">
                                        <label>Amount</label>
                                        <input type="text" placeholder="Amount To be Paid" name="amount" onkeyup='lnameValidation(this)'required>
                                        <span id="last" class="new" style="color:red;"></span> 
                                </div>
 
                                   

                                        <button type="submit" value="su" class="nextBtn" name="submit">
                                                <span class="btnText">Submit</span>
                                                <i class="uil uil-navigator"></i>
                                            </button>
        </div>
 
        
       

</form>

</html>

			
		</section>
	</div>

</body>
</html>