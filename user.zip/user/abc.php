<?php 
require("dbconn.php");
if(isset($_POST['submit']))
{

$email=['email'];
$village=$_POST['village'];
$category=$_POST['category'];
$a=$_FILES['file']['name'];
$b=$_FILES['file2']['name'];
move_uploaded_file($_FILES['file']['tmp_name'],"image/".$a);
move_uploaded_file($_FILES['file2']['tmp_name1'],"images/".$b);
$sqlInsert="INSERT INTO `tbl_app`(`email`, `village`, `category`,`image`,`images`) VALUES('$email','$village','$category','$a','$b')";
$queryInsert=mysqli_query($conn,$sqlInsert);
if($queryInsert)
{
  echo "<script>alert('Data inserted Successfully!!');window.location='userdash.php'</script>";
}
}
?>





<!DOCTYPE html>
<html lang="en">
<head>
<title>Dashboard</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="styles.css">
 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>

<body>
<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">USER <b>DASHBOARD</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		</h2>
		<i class="fa fa-user" aria-hidden="true"></i>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<img src="userpic.png">
				<h4>WELCOME!</h4>
			</div>
			<ul>
				<li>
					<a href="change.php">
						<i class="fa fa-desktop" aria-hidden="true"></i>
						<span>Change Password</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="fa fa-plus icons"></i>
						<span>Apply Application</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="fa fa-plus icons" aria-hidden="true"></i>
						<span>Pay tax</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="fa fa-info-circle" aria-hidden="true"></i>
						<span>Request Service</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="fa fa-cog" aria-hidden="true"></i>
						<span>Setting</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-power-off" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
      <!-- partial -->
      <div class="main-panel">        
        <div class="content-wrapper">
         
                 
            
                  
                  <form class="forms-sample" action="" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                      <label for="exampleInputName1">User Name</label>
                      <input type="text" class="form-control"name="email" id="email" required placeholder="Enter user name"onchange="Validstr();"/>
                    </div>
                    <span id="msg1" style="color:red;"></span>
                        <script>
                    function Validstr() 
                    {
                    var val = document.getElementById('name').value;
                     if (!val.match(/^[a-zA-Z ]*$/)) 
                     {
                     document.getElementById('msg1').innerHTML="Only alphabets are allowed ";
                       document.getElementById('name').value = "";
                        return false;
                    }
                    document.getElementById('msg1').innerHTML=" ";
                   return true;
                    }
                   </script>

                    <div class="form-group">
                      <label for="exampleInputName1">Village</label>
                      <input type="text" class="form-control" name="village" id="village" required placeholder="Artist Name"onchange="Validstr();"/>
                    </div>
                    <span id="msg1" style="color:red;"></span>
                        <script>
                    function Validstr() 
                    {
                    var val = document.getElementById('name').value;
                     if (!val.match(/^[a-zA-Z ]*$/)) 
                     {
                     document.getElementById('msg1').innerHTML="Only alphabets are allowed ";
                       document.getElementById('name').value = "";
                        return false;
                    }
                    document.getElementById('msg1').innerHTML=" ";
                   return true;
                    }
                   </script>
                   
                   <div class="form-group">
                      <label for="exampleSelectGender">Category</label>
                        <select class="form-control" name="category" id="category">
                            <option>Choose</option>
                            
                        <?php 
                      $sql="select * from category";
                      $query=mysqli_query($conn,$sql);
                      while($row = mysqli_fetch_array($query)){ ?>
                     <option value="<?php echo $row['cid'];?>"><?php echo ($row['cname']); ?></option>
                     <?php }
                      ?>
                     </select>
                        </select>
                      </div>


                     
                      </div>

                      <div class="form-group">
                      <label for="exampleInputName1">Category</label>
                      <input type="text" class="form-control"name="cname" id="name" required placeholder="Price" onchange="Validstr();"/>
                    </div>
                    <span id="msg1" style="color:red;"></span>
                        <script>
                    function Validstr() 
                    {
                    var val = document.getElementById('name').value;
                     if (!val.match(/^[a-zA-Z ]*$/)) 
                     {
                     document.getElementById('msg1').innerHTML="Only alphabets are allowed ";
                       document.getElementById('name').value = "";
                        return false;
                    }
                    document.getElementById('msg1').innerHTML=" ";
                   return true;
                    }
                   </script>





                     <div class="form-group">
                      <label for="exampleInputName1">Description</label>
                      <input type="text" class="form-control"name="dname" id="name" required placeholder="Description"onchange="Validstr();"/>
                    </div>
                    <span id="msg1" style="color:red;"></span>
                        <script>
                    function Validstr() 
                    {
                    var val = document.getElementById('name').value;
                     if (!val.match(/^[a-zA-Z ]*$/)) 
                     {
                     document.getElementById('msg1').innerHTML="Only alphabets are allowed ";
                       document.getElementById('name').value = "";
                        return false;
                    }
                    document.getElementById('msg1').innerHTML=" ";
                   return true;
                    }
                   </script>



                     <div class="form-group">
                      <label for="exampleFormControlFile1">Choose Image</label>
                      <input type="file" id="imgfile"  class="form-control-file" accept ="image/gif,image/jpg,image/jpeg,image/png" oninput="pic.src=window.URL.createObjectURL(this.files[0])" name="file">
                          <img id="pic" height=70px width=90px />

                     </div>
                     <div class="form-group">
                      <label for="exampleFormControlFile1">Choose Image</label>
                      <input type="file" id="imgfile1"  class="form-control-file" accept ="image/gif,image/jpg,image/jpeg,image/png" oninput="pic.src=window.URL.createObjectURL(this.files[0])" name="file2">
                          <img id="pic" height=70px width=90px />

                     </div>


                   <button type="submit" name="submit" class="btn btn-primary mr-2">Submit</button>
                    <button class="btn btn-light">Cancel</button>
                  </form>
                </div>
              </div>
            </div>
      
      </div>

      <script>
$(document).ready(function() {
	$('#category').on('change', function() {
			var category_id = this.value;
			$.ajax({
				url: "sql.php",
				type: "POST",
				data: {
					category_id: category_id
				},
				cache: false,
				success: function(dataResult){
					$("#sub_category").html(dataResult);
				}
			});
		
		
	});
});
</script>


     


  
</body>

</html>