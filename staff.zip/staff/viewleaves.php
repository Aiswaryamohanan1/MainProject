
<?php 
include ('../dbconn.php');
include '../session.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Dashboard</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="styles.css">
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">STAFF<b>DASHBOARD</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		</h2>
		<i class="fa fa-user" aria-hidden="true"></i>
	</header>
	<div class="body">
   <style>
        #builder {
        font-family: Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 100%;
        }

        #builder td, #builder th {
        border: 1px solid #ddd;
        padding: 8px;
        }

        /* #builder tr:nth-child(even){background-color: #f2f2f2;} */

        #builder tr:hover {background-color: #ddd;}

        #builder th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: grey;
        color: white;
        }
    </style>
</head>
<body>
    
          
          <nav class="side-bar">
			<div class="user-p">
				<img src="user.png">
				<h4>WELCOME!</h4>
			</div>
            <?php

    echo $_SESSION['email'];
 ?>
			<ul>
				<li>
					<a href="staffdash.php">
						<i class="fa fa-desktop" aria-hidden="true"></i>
						<span>Dashboard</span>
					</a>
				</li>
				<li>
					<a href="eee.php">
						<i class="fa fa-plus icons"></i>
						<span>Apply Leave</span>

					</a>
				</li>
				<li>
					<a href="viewleaves.php">
						<i class="fa fa-plus icons"></i>
				<span>View Leave</span>
				</a>
				</li>
				<li>
					<a href="viewduty.php">
						<i class="fa fa-plus icons" aria-hidden="true"></i>
						<span>View Duty</span>
					</a>
				</li>
				
				<li>
					<a href="changep.php">
						<i class="fa fa-cog" aria-hidden="true"></i>
						<span>Change Password</span>
					</a>
				</li>
				<li>
					<a href="../logout.php">
						<i class="fa fa-power-off" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
        
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>LEAVE STATUS</h2>   
                        
                       
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                    <table border=2 id ="approve"  class="content-table">

                                            <tr>
                                                <th>From Date</th>
                                                <th>To date</th>&nbsp;&nbsp;
                                                <th>status </th>&nbsp;&nbsp;
                                                
                                               
                                               
                                            </tr>
                                            <?php 
                                           
                                            $n=$_SESSION['email'];
                                            $query="select * from applyleave where email='$n'";
                                            $result=mysqli_query($conn,$query);
                                            while($row = mysqli_fetch_array($result))
                                            {
                                    
                                            ?>
                                    
                                            <tr>
                                                
                                                <td><?php echo $row['Fromdate'];?></td>
                                                <td><?php echo $row['Todate'];?></td>
                                                <td><?php echo $row['status'];?></td>
                                                
                                               <td>
                                            
                                       
                                        <?php
                                        }
                                        ?>
                                        
                                   
                                </table>
                            </div>
                        </div>
                    </div>
              </div>
    </div>  
                 <!-- /. ROW  -->
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
viewleaves.php
Displaying viewleaves.php.