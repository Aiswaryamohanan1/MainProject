<?php
     session_start();

     if(isset($_SESSION['email']))
     {
                                      // echo 'inside';                          
                            // echo '<a href="profile.php">'      
                                          // echo '<h2> welcome'.$_SESSION['username'].'</h2>';
                                  }
    ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title> index</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   <link rel="stylesheet" href="styles.css">
</head>
<body>
      <style>
  input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
textarea, select
 {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=date], select
 {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit]
 {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover
 {
  background-color: #45a049;
}

div
 {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
  </style>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
        <input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">STAFF<b>DASHBOARD</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">  <?php
                                                echo $_SESSION['email'];

                      ?> <a href="../login/logout.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
					</li>
				
					
          <li>
                        <a   href="index.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                     <li>
                        <a  href="profile.php"><i class="fa fa-desktop fa-3x"></i>Profile</a>
                    </li>
                    <li>
                        <a  href="changepasssw.php"><i class="fa fa-qrcode fa-3x"></i> change password</a>
                    </li>
                    </li>
                      
                    <li  >
                        <a class="active-menu" href="leave.php"><i class="fa fa-edit fa-3x"></i>Apply Leave </a>
                    </li>				
                    </li>
                        	
                </ul>
               
            </div>
            
        </nav>  
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
          
	   <div class="xs">
  	    <h3>Leave Application</h3>
        <?php
         $wid=$_SESSION['email'];
                         
                                       if(isset($_SESSION['status']))
                                       {
                                           ?>
                                          <div class="alert alert-success" role="alert">
        
       
                                 <?php echo $_SESSION['status'] ; ?>
                                 
                                    </div>
                                           <?php
                                           
                                           unset($_SESSION['status']);
                                       }
          
                                       ?>
  	    <div class="well1 white">
        <form class="form-floating ng-pristine ng-invalid ng-invalid-required ng-valid-email ng-valid-url ng-valid-pattern"  action="leaveaction.php" method="POST">
          <fieldset>
            <div class="form-group">
              <label class="control-label">To Date</label>
              <input type="date" class="form-control1 ng-invalid ng-invalid-required ng-touched" id="demo" name="todate" required="">
            </div>
            <div class="form-group">
              <label class="control-label">From Date</label>
              <input type="date" class="form-control1 ng-invalid ng-valid-email ng-invalid-required ng-touched" id="demo1" name="fromdate" required="">
            </div>
            <div class="form-group">
              <label class="control-label">Reason</label>
              <input type="text" class="form-control1 ng-invalid ng-invalid-required ng-touched" name="reason" required="">
            </div>
         
            <div class="form-group">
              <button type="submit" name="btnsubmit" class="btn btn-primary">Submit</button>
              <button type="reset" class="btn btn-default">Reset</button>
            </div>
          </fieldset>
        </form>
      </div>
    </div>
    
   </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/metisMenu.min.js"></script>
<script>
  var date=new Date();
  var tdate=date.getDate();
  var month=date.getMonth() + 1;
  if(tdate < 10)
{
  tdate='0'+tdate;
} 
 if(month < 10)
{
  month='0' +month;
}
var year=date.getUTCFullYear();
var minDate=year+"-"+month+"-"+tdate;
document.getElementById("demo").setAttribute('min',minDate);
document.getElementById("demo1").setAttribute('min',minDate);  
</script>
<script src="js/custom.js"></script>
                </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>