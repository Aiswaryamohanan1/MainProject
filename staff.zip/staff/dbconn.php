<?php
$conn = mysqli_connect("localhost", "root", "", "etaluk1");
// if($conn){
//     echo "Connected";
// }
// else{
//     echo "not connected";
// }
?>