<?php
session_start();
if(isset($_SESSION['email']))
	{
	echo "<div class = 'textview'>";
	include 'dbconn.php';
	echo "<h1>Leave Management System</h1>";

	echo "<center>";
	echo "<h2>My All Leaves</h2>";
	$sql = "SELECT email,fname,lastname FROM userreg WHERE email = '".$_SESSION['email']."'";
	$result = $conn->query($sql);
	if($result->num_rows > 0)
		{
		while($row = $result->fetch_assoc())
			{
			$email = $row["email"];
			$sql2 = "SELECT * FROM applyleave WHERE email= '".$email."'";
			$result2 = $conn->query($sql2);
			if($result2->num_rows > 0)
				{
				echo "<table>";
				echo "<tr><th>Name</th>";
				
				echo "<th>Status</th>";
				
				while($row2 = $result2->fetch_assoc())
					{
					echo "<tr><td>".$row2["fname"]."</td>";
			
					echo "<td>".$row2["tatus"]."</td>";
					echo "<td><a href = 'leaves/".$_SESSION['email'].$row2["Fromdate"].$row2["reason"].$row2["Todate"].".pdf'>Download</a></td>";
					}
				echo "</table>";
				echo "</center>";
				echo "</div>";
				}
			}
		}
	}
else
	{
	header('location:index.php?err='.urlencode('Please Login First To Access This Page !'));
	exit();
	}
?>