<?php session_start();

if(isset($_SESSION['email']))
{
                                 // echo 'inside';                          
                       // echo '<a href="profile.php">'      
                                     // echo '<h2> welcome'.$_SESSION['username'].'</h2>';
                             }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="styles.css">
</head>
<body><style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
textarea, select
 {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=date], select
 {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
</style>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">STAFF<b>DASHBOARD</b>
       
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		</h2>
		<i class="fa fa-user" aria-hidden="true"></i>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<img src="user.png">
				<h4>WELCOME!</h4>
                <?php echo $_SESSION['email'];?>
			</div>
			<ul>
				<li>
					<a href="staffdash.php">
						<i class="fa fa-desktop" aria-hidden="true"></i>
						<span>Dashboard</span>
					</a>
				</li>
				<li>
					<a href="eee.php">
						<i class="fa fa-plus icons"></i>
						<span>Apply Leave</span>
					</a>
				</li>
				<li>
					<a href="viewduty.php">
						<i class="fa fa-plus icons" aria-hidden="true"></i>
						<span>View Duty</span>
					</a>
				</li>
				
				<li>
					<a href="#">
						<i class="fa fa-cog" aria-hidden="true"></i>
						<span>Setting</span>
					</a>
				</li>
				<li>
					<a href="logout.php">
						<i class="fa fa-power-off" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
        <section class="section-1">
        <?php
        $wid=$_SESSION['email'];
                         
                         if(isset($_SESSION['status']))
                         {
                             ?>
                            <div class="alert alert-success" role="alert">


                   <?php echo $_SESSION['status'] ; ?>
                   
                      </div>
                             <?php
                             
                             unset($_SESSION['status']);
                         }

                         ?>
<div class="well1 white">
<form class="form-floating ng-pristine ng-invalid ng-invalid-required ng-valid-email ng-valid-url ng-valid-pattern"  action="leaveaction.php" method="POST">
<fieldset>
<div class="form-group">
<label class="control-label">From Date</label>
<input type="date" class="form-control1 ng-invalid ng-invalid-required ng-touched" id="demo" name="Fromdate" required="">
</div>
<div class="form-group">
<label class="control-label">To Date</label>
<input type="date" class="form-control1 ng-invalid ng-valid-email ng-invalid-required ng-touched" id="demo1" name="Todate" required="">
</div>
<div class="form-group">
<label class="control-label">Reason</label>
<input type="text" class="form-control1 ng-invalid ng-invalid-required ng-touched" name="Reason" required="">
</div>

<div class="form-group">
<button type="submit" name="btnsubmit" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-default">Reset</button>
</div>
</fieldset>
</form>
</div>
</div>
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/metisMenu.min.js"></script>
<script>
  var date=new Date();
  var tdate=date.getDate();
  var month=date.getMonth() + 1;
  if(tdate < 10)
{
  tdate='0'+tdate;
} 
 if(month < 10)
{
  month='0' +month;
}
var year=date.getUTCFullYear();
var minDate=year+"-"+month+"-"+tdate;
document.getElementById("demo").setAttribute('min',minDate);
document.getElementById("demo1").setAttribute('min',minDate);  
</script>
<script src="js/custom.js"></script>
                </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>