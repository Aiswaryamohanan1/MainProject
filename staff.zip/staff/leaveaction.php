<?php
include("../dbconn.php");
session_start();
if(isset($_POST["btnsubmit"]))
{
    $wid=$_SESSION['email'];
    
    $Fromdate=$_POST['Fromdate'];
    $Todate=$_POST['Todate'];
    $Reason=$_POST['Reason'];
   
    
    $sql=mysqli_query($conn,"INSERT INTO applyleave(`email`,`Fromdate`,`Todate`,`Reason`,`status`) VALUES('$wid','$Fromdate','$Todate','$Reason','Pending')");

    
    
    if($sql)
      {
       $_SESSION['status'] = "Registered Successfully";
       
       header('Location: leave.php');
      }
    else
      {
        $_SESSION['status']="Data not inserted/Already Exit";
       
       header('Location: leave.php');
    
      }
    }
    
    
  	
?>